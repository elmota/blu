import { Sucursales } from './sucursales';

describe('Sucursales', () => {
  it('should create an instance', () => {
    expect(new Sucursales()).toBeTruthy();
  });
});
