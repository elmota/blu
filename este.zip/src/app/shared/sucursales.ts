export class Sucursales {
    agency_id: string;
    agency_name: string;
    location: [];
    open_hours: [];
}

export class Ciudades {
    pais: string;
    comuna: string;
}
