import { Component, OnInit } from '@angular/core';
import { SucursalesService } from './../../services/sucursales/sucursales.service';

@Component({
  selector: 'app-sucursales',
  templateUrl: './sucursales.component.html',
  styleUrls: ['./sucursales.component.scss'],
  providers: [SucursalesService]
})
export class SucursalesComponent implements OnInit {
  country: any;

  countries: any[];
  filteredCountriesSingle: any[];

  comunas: any;
  ciudades: any;
  regiones: any;
  sucursales: any;
  sucursal: any;
  placeholder = true;
  display = false;
  cars = [
    {
      "ciudad": "stgo",
      "direccion": "aca",
      "telefono": "8276226"
    },
    {
      "ciudad": "stgo",
      "direccion": "aca",
      "telefono": "8276226"
    },
    {
      "ciudad": "stgo",
      "direccion": "aca",
      "telefono": "8276226"
    },
    {
      "ciudad": "stgo",
      "direccion": "aca",
      "telefono": "8276226"
    },
    {
      "ciudad": "stgo",
      "direccion": "aca",
      "telefono": "8276226"
    }
  ];

  constructor(private suc: SucursalesService) { }

  ngOnInit() {
    this.loadCiudades();
    this.loadComunas();
  }
  loadCiudad() {
    this.suc.getCiudades().subscribe((data: {}) => {
      console.log('Data', data);
    }
    )
  }

  loadCiudades() {
    console.log('holi');
    this.suc.getRegiones().subscribe((data: {}) => {
      console.log('Datax', data);
      this.regiones = data;
      // this.placeholder = true;
      // this.display = true;
    }
    )
  }
  loadSucursales() {
    this.suc.getSucursales().subscribe((data: {}) => {
      console.log('Data', data);
      this.sucursales = data;
      this.placeholder = false;
      // this.display = true;
    }
    )
  }

  loadComunas() {
    this.suc.getComunas().subscribe((data: {}) => {
      console.log('Data', data);
      this.comunas = data;
      // this.display = true;
    }
    )
  }

  loadMap(i) {
    this.display = true;
    console.log(i);
    this.sucursal = this.sucursales[0];
  }
  loadResults() {
    this.placeholder = false;
  }
  click() {
    this.display = true;
  }
  filterCountrySingle(event) {
    let query = event.query;
    this.suc.getRegiones().subscribe(countries => {
      this.filteredCountriesSingle = this.filterCountry(query, countries);
    });
  }
  filterCountry(query, countries: any[]): any[] {
    //in a real application, make a request to a remote url with the query and return filtered results, for demo we filter at client side
    let filtered: any[] = [];
    for (let i = 0; i < countries.length; i++) {
      let country = countries[i];
      if (country.nombre.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        console.log('COUNTRI', country.nombre, 'QUERY', query)
        filtered.push(country.nombre);
      }
    }
    return filtered;
  }
}
